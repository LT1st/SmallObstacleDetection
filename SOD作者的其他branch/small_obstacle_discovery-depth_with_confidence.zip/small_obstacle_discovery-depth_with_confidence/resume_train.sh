CUDA_VISIBLE_DEVICES=0,1,2,3 python train.py --resume /scratch/adityaRRC/logs/run/lnf/deeplab-drn/experiment_0/checkpoint.pth.tar --batch-size 2 --epoch 40 --mode train --ft --dataset lnf
